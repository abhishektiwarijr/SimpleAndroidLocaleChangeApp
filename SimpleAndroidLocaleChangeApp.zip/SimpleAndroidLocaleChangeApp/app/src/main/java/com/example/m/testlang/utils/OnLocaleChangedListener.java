package com.example.m.testlang.utils;

/**
 * Created by Abhishek Tiwari on 22.09.2017.
 **/
public interface OnLocaleChangedListener {
    void beforeLocaleChanged();
    void afterLocaleChanged();
}
