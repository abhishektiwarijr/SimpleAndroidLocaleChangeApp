# SimpleAndroidLocaleChangeApp
It's a very simple demo application to change Locale of the app which reflects on the fly in whole app even in fragments or viewpagers.
